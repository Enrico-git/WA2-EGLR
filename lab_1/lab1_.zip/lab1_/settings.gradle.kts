
rootProject.name = "lab1_"

