package it.polito.wa2.webflux

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WebfluxApplicationTests {

    @Test
    fun contextLoads() {
    }

}
